# -*- coding: latin-1 -*-

from string import *
import xbmcplugin, xbmcaddon
import sys, os.path
import urllib,urllib2, filecmp
import re, random, string, shutil
import xbmc, xbmcgui
import re, os, time, datetime, traceback
import cookielib, htmlentitydefs
from sportsdevil import *
from helpers import *

enable_debug = True
__settings__ = xbmcaddon.Addon(id='plugin.video.SportsDevil')
__language__ = __settings__.getLocalizedString


class Main:

    def __init__(self):
        log('Initializing SportsDevil')
        self.pDialog = None
        self.curr_file = ''
        self.urlList = []
        self.extensionList = []
        self.selectionList = []
        self.videoExtension = '.flv'
        self.currentlist = CCurrentList()
        log('SportsDevil initialized')
        self.run()


    def playVideo(self, videoItem):
        if videoItem == None:
            return
        if videoItem.infos_values[videoItem.infos_names.index('url')] == '':
            return
        url = videoItem.infos_values[videoItem.infos_names.index('url')]
        try:
            title = videoItem.infos_values[videoItem.infos_names.index('title')]
        except:
            title = '...'

        if url.startswith('call://'):
            call_url = url.replace('call://','')
            xbmc.executebuiltin('XBMC.RunPlugin(' + call_url +')')
            if call_url.startswith('plugin://plugin.program.jdownloader'):
              xbmc.executebuiltin('Notification(Sent to JDownloader:,' + str(title) + ')')
            return;
        try:
            icon = videoItem.infos_values[videoItem.infos_names.index('icon')]
        except:
            icon = os.path.join(imgDir, 'video.png')
        try:
            urllib.urlretrieve(icon, os.path.join(cacheDir, 'thumb.tbn'))
            icon = os.path.join(cacheDir, 'thumb.tbn')
        except:
            if enable_debug:
                traceback.print_exc(file = sys.stdout)
            icon = os.path.join(imgDir, 'video.png')
        url = urllib.unquote_plus(url)
        flv_file = url
        listitem = xbmcgui.ListItem(title, title, icon, icon)
        listitem.setInfo('video', {'Title':title})

        if url.startswith('plugin://'):
            #listitem.setProperty('IsFolder','false')
            #listitem.setProperty('IsPlayable','true')
            xbmcplugin.setResolvedUrl(handle=self.handle, succeeded=False, listitem=listitem)

        for video_info_name in videoItem.infos_names:
            try:
                listitem.setInfo(type = 'Video', infoLabels = {video_info_name: videoItem.infos_values[videoItem.infos_names.index(video_info_name)]})
            except:
                pass
        if self.currentlist.skill.find('nodownload') == -1:
            if __settings__.getSetting('download') == 'true':
                self.pDialog = xbmcgui.DialogProgress()
                self.pDialog.create('SportsDevil', __language__(30050), __language__(30051))
                flv_file = self.downloadMovie(url, title)
                self.pDialog.close()
                if flv_file == None:
                    dialog = xbmcgui.Dialog()
                    dialog.ok('SportsDevil Info', __language__(30053))
            elif __settings__.getSetting('download') == 'false' and __settings__.getSetting('download_ask') == 'true':
                dia = xbmcgui.Dialog()
                if dia.yesno('', __language__(30052)):
                    self.pDialog = xbmcgui.DialogProgress()
                    self.pDialog.create('SportsDevil', __language__(30050), __language__(30051))
                    flv_file = self.downloadMovie(url, title)
                    self.pDialog.close()
                    if flv_file == None:
                        dialog = xbmcgui.Dialog()
                        dialog.ok('SportsDevil Info', __language__(30053))
        else:
            flv_file = None

        player_type = {0:xbmc.PLAYER_CORE_AUTO, 1:xbmc.PLAYER_CORE_MPLAYER, 2:xbmc.PLAYER_CORE_DVDPLAYER}[int(__settings__.getSetting('player_type'))]
        if self.currentlist.player == 'auto':
            player_type = xbmc.PLAYER_CORE_AUTO
        elif self.currentlist.player == 'mplayer':
            player_type = xbmc.PLAYER_CORE_MPLAYER
        elif self.currentlist.player == 'dvdplayer':
            player_type = xbmc.PLAYER_CORE_DVDPLAYER
        if flv_file != None and os.path.isfile(flv_file):
            log('Play: ' + str(flv_file))
            xbmc.Player(player_type).play(str(flv_file), listitem)
        else:
            log('Play: ' + str(url))
            xbmc.Player(player_type).play(str(url), listitem)
        #xbmc.sleep(200)

    def downloadMovie(self, url, title):
        log('Trying to download video ' + str(url))
	if __settings__.getSetting('download_Path') == '':
	    try:
		dl_path = xbmcgui.Dialog().browse(0, __language__(30017),'files', '', False, False)
		__settings__.setSetting(id='download_path', value=dl_path)
		if not os.path.exists(dl_path):
		    os.mkdir(dl_path)
	    except:pass
        file_path = xbmc.makeLegalFilename(os.path.join(__settings__.getSetting('download_Path'), title + self.videoExtension))
        if os.path.isfile(file_path):
            file_path = xbmc.makeLegalFilename(self.currentlist.randomFilename(prefix = file_path[:file_path.rfind('.')] + '&', suffix = self.videoExtension))
        try:
            urllib.urlretrieve(url, file_path, self.video_report_hook)
            log('Video ' + str(url) + ' downloaded to ' + repr(file_path))
            return file_path
        except IOError:
            title = first_clean_filename(title)
            file_path = xbmc.makeLegalFilename(os.path.join(__settings__.getSetting('download_Path'), title + self.videoExtension))
            if os.path.isfile(file_path):
                file_path = xbmc.makeLegalFilename(self.currentlist.randomFilename(prefix = file_path[:file_path.rfind('.')] + '&', suffix = self.videoExtension))
            try:
                urllib.urlretrieve(url, file_path, self.video_report_hook)
                log('Video ' + str(url) + ' downloaded to ' + repr(file_path))
                return file_path
            except IOError:
                title = second_clean_filename(title)
                file_path = xbmc.makeLegalFilename(os.path.join(__settings__.getSetting('download_Path'), title + self.videoExtension))
                if os.path.isfile(file_path):
                    file_path = xbmc.makeLegalFilename(self.currentlist.randomFilename(prefix = file_path[:file_path.rfind('.')] + '&', suffix = self.videoExtension))
                try:
                    urllib.urlretrieve(url, file_path, self.video_report_hook)
                    log('Video ' + str(url) + ' downloaded to ' + repr(file_path))
                    return file_path
                except IOError:
                    title = third_clean_filename(title)
                    file_path = xbmc.makeLegalFilename(os.path.join(__settings__.getSetting('download_Path'), title + self.videoExtension))
                    if os.path.isfile(file_path):
                        file_path = xbmc.makeLegalFilename(self.currentlist.randomFilename(dir = __settings__.getSetting('download_Path'), suffix = self.videoExtension))
                    try:
                        urllib.urlretrieve(url, file_path, self.video_report_hook)
                        log('Video ' + str(url) + ' downloaded to ' + repr(file_path))
                        return file_path
                    except IOError:
                        title = self.currentlist.randomFilename()
                        file_path = xbmc.makeLegalFilename(os.path.join(__settings__.getSetting('download_Path'), title + self.videoExtension))
                        if os.path.isfile(file_path):
                            file_path = xbmc.makeLegalFilename(self.currentlist.randomFilename(prefix = file_path[:file_path.rfind('.')] + '&', suffix = self.videoExtension))
                        try:
                            urllib.urlretrieve(url, file_path, self.video_report_hook)
                            log('Video ' + str(url) + ' downloaded to ' + repr(file_path))
                            return file_path
                        except:
                            pass
                    except:
                        pass
                except:
                    pass
            except:
                pass
        except:
            pass
        xbmc.sleep(500)
        if os.path.isfile(file_path):
            try:
                os.remove(file_path)
            except:
                if enable_debug:
                    traceback.print_exc(file = sys.stdout)
        return None

    def video_report_hook(self, count, blocksize, totalsize):
        percent = int(float(count * blocksize * 100) / totalsize)
        self.pDialog.update(percent, __language__(30050), __language__(30051))
        if self.pDialog.iscanceled():
            raise KeyboardInterrupt

    def TargetFormatter(self, url, cfg_file): # Site specific target url handling
        return url

    def parseView(self, url):
        lItem = self.currentlist.decodeUrl(url)
        url = lItem.infos_values[lItem.infos_names.index('url')]
        ext = self.currentlist.getFileExtension(url)
        if ext == 'cfg' or ext == 'list':
            result = self.currentlist.loadLocal(url, lItem = lItem)
        elif ext == 'add':
            url = urllib.unquote_plus(url)
            self.currentlist.addItem(url[:len(url) - 4])
            return -2
        elif ext == 'remove':
            dia = xbmcgui.Dialog()
            if dia.yesno('', __language__(30054)):
                url = urllib.unquote_plus(url)
                self.currentlist.removeItem(url[:len(url) - 7])
                xbmc.executebuiltin('Container.Refresh')
            return -2
        elif ext == 'videodevil' or ext == 'dwnlddevil':
            url = urllib.unquote_plus(url)
            url = url[:len(url) - 11]
            try:
                cfg_file = lItem.infos_values[lItem.infos_names.index('cfg')]
                lItem.infos_values[lItem.infos_names.index('url')] = self.TargetFormatter(url, cfg_file)
            except:
                lItem.infos_values[lItem.infos_names.index('url')] = url
            try:
                self.videoExtension = '.' + lItem.infos_values[lItem.infos_names.index('extension')]
            except:
                pass
            if ext == 'videodevil':
                result = self.playVideo(lItem)
            else:
                self.pDialog = xbmcgui.DialogProgress()
                self.pDialog.create('SportsDevil', __language__(30050), __language__(30051))
                self.downloadMovie(lItem.infos_values[lItem.infos_names.index('url')], lItem.infos_values[lItem.infos_names.index('title')])
                self.pDialog.close()
            return -2
        else:
            result = self.currentlist.loadRemote(lItem.infos_values[lItem.infos_names.index('url')], lItem = lItem)

        xbmcplugin.addSortMethod(handle = self.handle, sortMethod = xbmcplugin.SORT_METHOD_LABEL)
        if self.currentlist.sort.find('label') != -1:
            xbmcplugin.addSortMethod(handle = self.handle, sortMethod = xbmcplugin.SORT_METHOD_LABEL)
        if self.currentlist.sort.find('size') != -1:
            xbmcplugin.addSortMethod(handle = self.handle, sortMethod = xbmcplugin.SORT_METHOD_SIZE)
        if self.currentlist.sort.find('duration') != -1:
            xbmcplugin.addSortMethod(handle = self.handle, sortMethod = xbmcplugin.SORT_METHOD_DURATION)
        if self.currentlist.sort.find('genre') != -1:
            xbmcplugin.addSortMethod(handle = self.handle, sortMethod = xbmcplugin.SORT_METHOD_GENRE)
        if self.currentlist.sort.find('rating') != -1:
            xbmcplugin.addSortMethod(handle = self.handle, sortMethod = xbmcplugin.SORT_METHOD_VIDEO_RATING)
        if self.currentlist.sort.find('date') != -1:
            xbmcplugin.addSortMethod(handle = self.handle, sortMethod = xbmcplugin.SORT_METHOD_DATE)

        # Autoselect single folder 1
        tmpUrl = ''
        if self.currentlist.skill.find('autoselect') != -1:
            while len(self.currentlist.items) == 1:
                m = self.currentlist.items[0]
                try:
                    m_type = m.infos_values[m.infos_names.index('type')]
                except:
                    m_type = 'rss'
                if m_type == 'rss':
                    try:
                        log('Autoselect - ' + m.infos_values[m.infos_names.index('title')])
                        tmpCfg = m.infos_values[m.infos_names.index('cfg')]
                        tmpUrl = m.infos_values[m.infos_names.index('url')]

                        result = self.currentlist.loadLocal(tmpCfg, lItem = m)
                        self.currentlist.rules = []
                        result = self.currentlist.loadRemote(tmpUrl, lItem = m)
                        log(str(len(self.currentlist.items)) + ' items ' + tmpCfg + ' -> ' + tmpUrl)
                    except:
                        log('Couldn\'t autoselect')
                else:
                    break

        # Find Redirects automatically
        if len(self.currentlist.items) == 0:
            maxIt = 3
            i = 1
            startUrl = lItem.infos_values[lItem.infos_names.index('url')]
            if tmpUrl != '':
                startUrl = tmpUrl
            while i <= maxIt and self.currentlist.videoCount() == 0:
                log(str(i) + '.Try: ' + startUrl)
                red = findRedirect(startUrl)
                log('Redirect: ' + red)
                result = self.currentlist.loadLocal(lItem.infos_values[lItem.infos_names.index('cfg')], lItem = lItem)
                self.currentlist.rules = []
                result = self.currentlist.loadRemote(red,lItem = lItem)
                if startUrl == red:
                    break
                startUrl = red
                i += 1

        # Autoselect single folder 2
        tmpUrl = ''
        if self.currentlist.skill.find('autoselect') != -1:
            while len(self.currentlist.items) == 1:
                m = self.currentlist.items[0]
                try:
                    m_type = m.infos_values[m.infos_names.index('type')]
                except:
                    m_type = 'rss'
                if m_type == 'rss':
                    try:
                        log('Autoselect - ' + m.infos_values[m.infos_names.index('title')])
                        tmpCfg = m.infos_values[m.infos_names.index('cfg')]
                        tmpUrl = m.infos_values[m.infos_names.index('url')]

                        result = self.currentlist.loadLocal(tmpCfg, lItem = m)
                        self.currentlist.rules = []
                        result = self.currentlist.loadRemote(tmpUrl, lItem = m)
                        log(str(len(self.currentlist.items)) + ' items ' + tmpCfg + ' -> ' + tmpUrl)
                    except:
                        log('Couldn\'t autoselect')
                else:
                    break

        # Autoplay single Video
        if __settings__.getSetting('autoplay') == 'true' and len(self.currentlist.items) == 1 and self.currentlist.videoCount() == 1:
            videoItem = self.currentlist.getVideo()
            result = self.playVideo(videoItem)
            return -2
        elif __settings__.getSetting('autoplay') == 'true' and len(self.currentlist.items) == 0:
            dialog = xbmcgui.Dialog()
            dialog.ok('SportsDevil Info', 'No stream available')
            return
        if True:
            for m in self.currentlist.items:
                m_url = m.infos_values[m.infos_names.index('url')]
                try:
                    m_type = m.infos_values[m.infos_names.index('type')]
                except:
                    m_type = 'rss'
                try:
                    m_icon = m.infos_values[m.infos_names.index('icon')]
                except:
                    m_icon = ''
                m_title = clean_safe(m.infos_values[m.infos_names.index('title')])

                if m_type == 'search' and 'once' in m.infos_names:
                    p_reg = re.compile('^' + m.infos_values[m.infos_names.index('once')] + '$', re.IGNORECASE + re.DOTALL + re.MULTILINE)
                    m_reg = p_reg.match(unquote_safe(url))
                    if  (m_reg is None):
                        continue

                if m_type == 'rss' or m_type == 'search':
                    self.addListItem(m_title, self.currentlist.codeUrl(m), m_icon, len(self.currentlist.items), m)
                elif m_type.find('video') != -1:
                    self.addListItem(m_title, self.currentlist.codeUrl(m, 'videodevil'), m_icon, len(self.currentlist.items), m)
        return result

    def addListItem(self, title, url, icon, totalItems, lItem):
        u = sys.argv[0] + '?url=' + url
        liz = xbmcgui.ListItem(title, title, icon, icon)
        liz.setProperty('fanart_image', os.path.join(rootDir, 'fanart.jpg'))

        if self.currentlist.getFileExtension(url) == 'videodevil' and self.currentlist.skill.find('nodownload') == -1:
            action = 'XBMC.RunPlugin(%s.dwnlddevil)' % u[:len(u)-11]
            try:
                liz.addContextMenuItems([(__language__(30007), action)])
            except:
                pass
        if self.currentlist.skill.find('add') != -1:
            action = 'XBMC.RunPlugin(%s.add)' % u
            try:
                liz.addContextMenuItems([(__language__(30010), action)])
            except:
                pass
        if self.currentlist.skill.find('remove') != -1:
            action = 'XBMC.RunPlugin(%s.remove)' % u
            try:
                liz.addContextMenuItems([(__language__(30011), action)])
            except:
                pass
        for video_info_name in lItem.infos_names:
            if video_info_name.find('context.') != -1:
                try:
                    cItem = lItem
                    cItem.infos_values[lItem.infos_names.index('url')] = lItem.infos_values[lItem.infos_names.index(video_info_name)]
                    cItem.infos_values[lItem.infos_names.index('type')] = 'rss'
                    action = 'XBMC.RunPlugin(%s)' % (sys.argv[0] + '?url=' + self.currentlist.codeUrl(cItem))
                    liz.addContextMenuItems([(video_info_name[video_info_name.find('.') + 1:], action)])
                except:
                    pass
            if video_info_name.find('.append') == -1 and video_info_name != 'url' and video_info_name != 'title' and video_info_name != 'icon' and video_info_name != 'type' and video_info_name != 'extension' and video_info_name.find('.tmp') == -1 and video_info_name.find('.append') == -1 and video_info_name.find('context.') == -1:
                try:
                    if video_info_name.find('.int') != -1:
                        liz.setInfo(type = 'Video', infoLabels = {capitalize(video_info_name[:video_info_name.find('.int')]): int(lItem.infos_values[lItem.infos_names.index(video_info_name)])})
                    elif video_info_name.find('.once') != -1:
                        liz.setInfo(type = 'Video', infoLabels = {capitalize(video_info_name[:video_info_name.find('.once')]): lItem.infos_values[lItem.infos_names.index(video_info_name)]})
                    else:
                        liz.setInfo(type = 'Video', infoLabels = {capitalize(video_info_name): lItem.infos_values[lItem.infos_names.index(video_info_name)]})
                except:
                    pass

        xbmcplugin.addDirectoryItem(handle = self.handle, url = u, listitem = liz, isFolder = True, totalItems = totalItems)

    def purgeCache(self):
        for root, dirs, files in os.walk(cacheDir , topdown = False):
            for name in files:
                os.remove(os.path.join(root, name))

    def run(self):
        log('SportsDevil running')
        try:
            self.handle = int(sys.argv[1])
            xbmcplugin.setPluginFanart(self.handle, os.path.join(rootDir, 'fanart.jpg'))
            paramstring = sys.argv[2]
            if len(paramstring) <= 2:
                if __settings__.getSetting('hide_warning') == 'false':
                    dialog = xbmcgui.Dialog()
                    if not dialog.yesno(__language__(30061), __language__(30062), __language__(30063), __language__(30064), __language__(30065), __language__(30066)):
                        return
                log('Cache directory: ' + str(cacheDir))
                log('Resource directory: ' + str(resDir))
                log('Image directory: ' + str(imgDir))

                if not os.path.exists(cacheDir):
                    log('Creating cache directory ' + str(cacheDir))
                    os.mkdir(cacheDir)
                    log('Cache directory created')

                log('Purging cache directory')
                self.purgeCache()
                log('Cache directory purged')



                # Get Main Menu
                self.parseView('sites.list')
                del self.currentlist.items[:]
                log('End of directory')
                xbmcplugin.endOfDirectory(self.handle)
            else:
                params = sys.argv[2]
                currentView = params[5:]
                if self.parseView(currentView) == 0:
                    xbmcplugin.endOfDirectory(self.handle)
                    log('End of directory')
        except Exception, e:
            if enable_debug:
                traceback.print_exc(file = sys.stdout)
            dialog = xbmcgui.Dialog()
            dialog.ok('SportsDevil Error', 'Error running SportsDevil.\n\nReason:\n' + str(e))
