# -*- coding: latin-1 -*-

from string import *
from helpers import *

import xbmcplugin, xbmcaddon
import sys, os.path
import urllib,urllib2, filecmp
import re, random, string, shutil
import xbmc, xbmcgui
import re, os, time, datetime, traceback
import cookielib, htmlentitydefs
import socket, base64


#import locale

__settings__ = xbmcaddon.Addon(id='plugin.video.SportsDevil')
__language__ = __settings__.getLocalizedString

rootDir = __settings__.getAddonInfo('path')

if rootDir[-1] == ';':rootDir = rootDir[0:-1]
cacheDir = os.path.join(rootDir, 'cache')
resDir = os.path.join(rootDir, 'resources')
imgDir = os.path.join(resDir, 'images')
modulesDir = os.path.join(resDir, 'modules')
catchersDir = os.path.join(resDir,'catchers')
dictsDir = os.path.join(resDir,'dictionaries')

pluginFanart = os.path.join(rootDir, 'fanart.jpg')

#socket.setdefaulttimeout(20)


enable_debug = True

def setCurrentUrl(url):
    f = open(os.path.join(cacheDir, 'currenturl'), 'w')
    f.write(url)
    f.close()

def getCurrentUrl():
    url = getFileContent(os.path.join(cacheDir, 'currenturl'))
    return url

def setLastUrl(url):
    f = open(os.path.join(cacheDir, 'lasturl'), 'w')
    f.write(url)
    f.close()

def getLastUrl():
    url = getFileContent(os.path.join(cacheDir, 'lasturl'))
    return url


def replaceCurrentUrl(data):
    m_reg = findall(data,'(@CURRENT_URL@)')
    if not (m_reg is None or len(m_reg) == 0):
      url = getCurrentUrl()
      for idat in m_reg:
          data = data.replace(idat,url)
    return data

def replacePlatform(data):
    m_reg = findall(data,'(@PLATFORM@)')
    if not (m_reg is None or len(m_reg) == 0):
      for idat in m_reg:
          data = data.replace(idat, os.environ.get('OS'))
    return data

def replaceLanguage(data):
    m_reg = findall(data,'(@LANGUAGE@)')
    if not (m_reg is None or len(m_reg) == 0):
      for idat in m_reg:
          if int(__settings__.getSetting('language')) == 0:
              data = data.replace(idat, 'en')
          else:
              data = data.replace(idat, 'de')
    return data

def containsImport(data):
    m_reg = findall(data,'(@IMPORT=([^@]+)@)')
    return (m_reg is not None and len(m_reg) > 0)

def replaceImport(data):
    m_reg = findall(data,'(@IMPORT=([^@]+)@)')
    if not (m_reg is None or len(m_reg) == 0):
        for idat in m_reg:
            pathImp = xbmc.translatePath(os.path.join(modulesDir, idat[1]))
            if not (os.path.exists(pathImp)):
                log('Skipped Import: ' + idat[1])
                continue
            dataImp = getFileContent(pathImp)
            dataImp = dataImp.replace('\r\n','\n')
            data = data.replace(idat[0], dataImp)
    return data


def customCfgReplacements(data, params=[]):
      #Imports
      while containsImport(data):
        data = replaceImport(data)

      #Parameters
      i=1
      for par in params:
          p_reg = re.compile('(@PARAM' + str(i) + '@)', re.IGNORECASE + re.DOTALL + re.MULTILINE)
          m_reg = p_reg.findall(data)
          if not (m_reg is None or len(m_reg) == 0):
              for idat in m_reg:
                  ptemp = str(params[i]).strip()
                  data = data.replace(idat, ptemp)
          i = i + 1

      #Catchers
      m_reg = findall(data,'(#*@CATCH\([^\)]+\)@)')
      if not (m_reg is None or len(m_reg) == 0):
          for idat in m_reg:
              if idat.startswith('#'):
                continue
              ps = idat[7:-2].strip().split(',')
              pathImp = xbmc.translatePath(os.path.join(catchersDir, ps[0].strip() + '.txt'))
              if not (os.path.exists(pathImp)):
                  log('Skipped Catcher: ' + ps[0].strip())
                  continue
              dataImp = getFileContent(pathImp)
              dataImp = dataImp.replace('@PARAM1@',ps[1].strip())
              dataImp = dataImp.replace('\r\n','\n')
              data = data.replace(idat, dataImp)

      #Current url
      data = replaceCurrentUrl(data)

      #Platform
      data = replacePlatform(data)

      #Language
      data = replaceLanguage(data)



      #Conditions
      starts = [match.start() for match in re.finditer(re.escape('@IF('), data)]
      for j in range(len(starts)-1,-1,-1):
          s = starts[j]
          p_reg = re.compile('((@IF\((.+?)\)@).*?(@ENDIF@))', re.IGNORECASE + re.DOTALL + re.MULTILINE)
          m_reg = p_reg.findall(data[s:])
          if not (m_reg is None or len(m_reg) == 0):
              for m in m_reg:
                  new_reg=p_reg.match(m[0])
                  condStr = new_reg.group(3)
                  hidePassage=False
                  if condStr.find('==') != -1:
                      condArr=condStr.split('==')
                      hidePassage = condArr[0].strip().lower() != condArr[1].strip().lower()
                  elif condStr.find('!=') != -1:
                      condArr=condStr.split('!=')
                      hidePassage = condArr[0].strip().lower() == condArr[1].strip().lower()

                  if hidePassage:
                      data = data.replace(str(new_reg.group(1)),'')
                  else:
                      tmpdata = str(new_reg.group(1))
                      tmpdata = tmpdata.replace(str(new_reg.group(2)),'',1)
                      tmpdata = tmpdata[:-len(str(new_reg.group(4)))]
                      data = data.replace(str(new_reg.group(1)),tmpdata)


      return data


def replaceFromDict(filename, wrd):
    pathImp = xbmc.translatePath(os.path.join(dictsDir, filename + '.txt'))
    if not (os.path.exists(pathImp)):
        log('Skipped Replacement: ' + filename)
    dict = getFileContent(pathImp)
    dict = dict.replace('\r\n','\n')

    p_reg = re.compile('^[^\r\n]+$', re.IGNORECASE + re.DOTALL + re.MULTILINE)
    m_reg = p_reg.findall(dict)

    word = wrd.replace(u'Ü','&Uuml;').replace(u'Ö','&Ouml;').replace(u'Ä','&Auml;')
    try:
      if m_reg and len(m_reg) > 0:
          index = ''
          words = []
          newword = ''
          for m in m_reg:
              if not m.startswith(' '):
                  index = m
                  del words[:]
              else:
                  replWord = m.strip()
                  words.append(replWord)
                  if word.find(' ') != -1:
                    newword = word.replace(replWord,index)

              if (word in words) or (word == index):
                  return index

          if newword != '' and newword != word:
            return newword
    except:
      log('Skipped Replacement: ' + word)

    return word

def get_redirected_url(url):
    import urllib2
    opener = urllib2.build_opener(urllib2.HTTPRedirectHandler)
    request = opener.open(url)
    return request.url

def getHTML(url, referer=''):
    cache = os.path.join(cacheDir, 'page.html')

    if url == getLastUrl():
        data = getFileContent(cache)
    else:
        data = getSource(url, referer)

        # Cache url
        setLastUrl(url)

        # Cache page
        f = open(cache, 'w')
        f.write(data)
        f.close()
    return data

def ifStringEmpty(str, trueStr, falseStr):
    if str == '':
        return trueStr
    else:
        return falseStr

def customConversion(src, convCommands):
    for convCommand in convCommands:
        if convCommand.startswith('convDate'):
            params = convCommand[9:-1]
            if params.find("','") != -1:
                paramArr = params.split("','")
                oldfrmt = paramArr[0].strip('\'')
                newfrmt = paramArr[1].strip('\'')
                src = convDate(src,str(oldfrmt), str(newfrmt))
            else:
                params = params.strip('\'')
                src = convDate(src,params)

        elif convCommand == 'smart_unicode':
            src = smart_unicode(convCommand[14:-1].strip('\'').replace('%s', src))

        elif convCommand == 'safeGerman':
            src = safeGerman(src)

        elif convCommand.startswith('safeRegex'):
            src = safeRegexEncoding(convCommand[10:-1].strip("'").replace('%s',smart_unicode(src)))

        elif convCommand.startswith('replaceFromDict('):
            params = convCommand[16:-1]
            params = params.strip('\'')
            src = replaceFromDict(str(params),src)

        elif convCommand.startswith('time('):
            src = time.time()

        elif convCommand.startswith('timediff'):
            params = convCommand[9:-1]
            params = params.strip('\'')
            src = timediff(src,params)

        elif convCommand.startswith('offset'):
            if __settings__.getSetting('timeoffset') == 'true':
                params = convCommand[7:-1]
                paramArr = params.split("','")
                t = paramArr[0].strip("'").replace('%s', src)
                o = paramArr[1].strip("'").replace('%s', src)

                fak = 1
                if o[0] == '-':
                    fak = -1
                    o = o[1:]

                pageOffSeconds = fak*(int(o.split(':')[0]) * 3600 + int(o.split(':')[1])*60)
                localOffSeconds = -1 * time.timezone
                offSeconds = localOffSeconds - pageOffSeconds

                ti = datetime.datetime(2000,1,1,int(t.split(':')[0]),int(t.split(':')[1]))

                offset=ti + datetime.timedelta(seconds=offSeconds)

                src = offset.strftime('%H:%M')



        elif convCommand.startswith('getSource'):
            params = convCommand[10:-1]
            paramPage = ''
            paramReferer = ''
            if params.find('\',\'') > -1:
                paramArr = params.split('\',\'')
                paramPage = paramArr[0].strip('\'')
                paramReferer = paramArr[1].strip('\'')
            else:
                paramPage = params.strip('\',\'')

            paramPage = paramPage.replace('%s', src)
            return getHTML(paramPage,paramReferer)

        elif convCommand.startswith('getRedirect'):
            param = convCommand[12:-1].strip("'")
            src = get_redirected_url(param.replace('%s', src))

        elif convCommand.startswith('quote'):
            param = convCommand[6:-1].strip("'")
            src = urllib2.quote(param.replace('%s', src))

        elif convCommand.startswith('unquote'):
            param = convCommand[8:-1].strip("'")
            src = urllib2.unquote(param.replace('%s', src))

        elif convCommand.startswith('regex'):
            src = smart_unicode(src)
            params = convCommand[6:-1]
            paramArr = params.split("','")
            paramText = paramArr[0].strip("'").replace('%s', src)
            paramRegex = paramArr[1].strip("'").replace('%s', src)
            p = re.compile(paramRegex, re.IGNORECASE + re.DOTALL + re.MULTILINE)
            m = p.match(paramText)
            if m:
              src = m.group(1)

        elif convCommand.startswith('parseText'):
            src = smart_unicode(src)
            params = convCommand[10:-1]
            paramArr = params.split("','")

            text = paramArr[0].strip("'").replace('%s',src)
            regex = paramArr[1].strip("'").replace('%s', src)
            vars = []
            if len(paramArr) > 2:
                vars = paramArr[2].strip("'").split('|')
            src = parseText(text, regex, vars)

        elif convCommand.startswith('getInfo'):
            src = smart_unicode(src)
            params = convCommand[8:-1]
            paramArr = params.split("','")
            paramPage = paramArr[0].strip("'").replace('%s', src)
            paramRegex = paramArr[1].strip("'").replace('%s', src)
            referer = ''
            vars=[]
            if len(paramArr) > 2:
                referer = paramArr[2].strip("'")
                referer = referer.replace('%s', src)
            if len(paramArr) > 3:
                vars = paramArr[3].strip("'").split('|')
            src = parseWebsite(paramPage, paramRegex, referer,vars)

        elif convCommand.startswith('decodeBase64'):
            src = src.strip('.js').replace('%3D','=')
            #log(src)
            #while src.__len__() %3 != 0:
            #    src += '='
            try:
                src = src.decode('base-64').replace('qo','')
            except:
                src = src

        elif convCommand.startswith('replace'):
            src = smart_unicode(src)
            params = convCommand[8:-1]
            paramArr = params.split('\',\'')
            paramstr = paramArr[0].replace('%s', src).strip('\'')
            paramSrch = paramArr[1].strip('\'')
            paramRepl = paramArr[2].strip('\'')
            src = paramstr.replace(paramSrch,paramRepl)

        elif convCommand.startswith('ifEmpty'):
            params = convCommand[8:-1]
            paramArr = params.split("','")

            paramSource = paramArr[0].strip("'").replace('%s', src)
            paramTrue = paramArr[1].strip("'").replace('%s', src)
            paramFalse = paramArr[2].strip("'").replace('%s', src)

            src = ifStringEmpty(paramSource, paramTrue, paramFalse)

        elif convCommand == 'debug':
            log(src)
    return src



class CListItem:
    def __init__(self):
        self.infos_names = []
        self.infos_values = []

class CItemInfo:
    def __init__(self):
        self.name = ''
        self.src = 'url'
        self.rule = ''
        self.default = ''
        self.build = ''
        self.convert = []

class CRuleItem:
    def __init__(self):
        self.infos = ''
        self.order = ''
        self.skill = ''
        self.curr = ''
        self.info_list = []
        self.url_build = ''

class CCurrentList:
    def __init__(self):
        self.start = ''
        self.section = ''
        self.player = ''
        self.sort = 'label'
        self.cfg = ''
        self.skill = ''
        self.reference = ''
        self.content = ''
        self.items = []
        self.rules = []


    def getKeyboard(self, default = '', heading = '', hidden = False):
        kboard = xbmc.Keyboard(default, heading, hidden)
        kboard.doModal()
        if kboard.isConfirmed():
            return urllib.quote_plus(kboard.getText())
        return ''

    def getFileExtension(self, filename):
        ext_pos = filename.rfind('.')
        if ext_pos != -1:
            return filename[ext_pos+1:]
        else:
            return ''

    def randomFilename(self, dir = cacheDir, chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', length = 8, prefix = '', suffix = '', attempts = 10000):
        for attempt in range(attempts):
            filename = ''.join([random.choice(chars) for i in range(length)])
            filename = prefix + filename + suffix
            if not os.path.exists(os.path.join(dir, filename)):
                return filename

    def videoCount(self):
        count = 0
        for item in self.items:
            if item.infos_values[item.infos_names.index('type')].find('video') != -1:
                count = count +1
        return count

    def getVideo(self):
        for item in self.items:
            if item.infos_values[item.infos_names.index('type')].find('video') != -1:
                return item

    def getItemFromList(self, listname, name):
        self.loadLocal(listname, False)
        for item in self.items:
            if item.infos_values[item.infos_names.index('url')] == name:
                return item
        return None

    def itemInLocalList(self, name):
        for item in self.items:
            if item.infos_values[item.infos_names.index('url')] == name:
                return True
        return False

    def getItem(self, name):
        item = None
        for root, dirs, files in os.walk(modulesDir):
            for listname in files:
                if self.getFileExtension(listname) == 'list':
                    item = self.getItemFromList(listname, name)
                if item != None:
                    return item
        return None

    def addItem(self, name):
        item = self.getItem(name)
        del self.items[:]
        try:
            self.loadLocal('entry.list', False)
        except:
            del self.items[:]
        if item and not self.itemInLocalList(name):
            self.items.append(item)
            self.saveList()
        return

    def removeItem(self, name):
        item = self.getItemFromList('entry.list', name)
        if item != None:
            self.items.remove(item)
            self.saveList()
        return

    def saveList(self):
        f = open(str(os.path.join(modulesDir, 'entry.list')), 'w')
        f.write(smart_unicode('########################################################\n').encode('utf-8'))
        f.write(smart_unicode('#             Added sites and live streams             #\n').encode('utf-8'))
        f.write(smart_unicode('########################################################\n').encode('utf-8'))
        f.write(smart_unicode('skill=remove\n').encode('utf-8'))
        f.write(smart_unicode('########################################################\n').encode('utf-8'))
        for item in self.items:
            f.write(smart_unicode('title=' + item.infos_values[item.infos_names.index('title')] + '\n').encode('utf-8'))
            for info_name in item.infos_names:
                if info_name != 'url' and info_name != 'title':
                    f.write(smart_unicode(info_name + '=' + item.infos_values[item.infos_names.index(info_name)] + '\n').encode('utf-8'))
            f.write(smart_unicode('url=' + item.infos_values[item.infos_names.index('url')] + '\n').encode('utf-8'))
            f.write(smart_unicode('########################################################\n').encode('utf-8'))
        f.close()
        return

    def codeUrl(self, item, suffix = ''):
        url_idx = item.infos_names.index('url')
        url = ''
        info_idx = 0
        firstInfo = True
        for info_name in item.infos_names:
            if info_idx != url_idx and item.infos_names[info_idx].find('.once') == -1:
                #info_value = urllib.quote(item.infos_values[info_idx])
                info_value = item.infos_values[info_idx]
                if firstInfo:
                    firstInfo = False
                    url = smart_unicode(item.infos_names[info_idx]) + ':' + smart_unicode(info_value)
                else:
                    url = smart_unicode(url) + '&' + smart_unicode(item.infos_names[info_idx]) + ':' + smart_unicode(info_value)
            info_idx = info_idx + 1
        if firstInfo:
            url = smart_unicode(item.infos_names[url_idx]) + ':' + smart_unicode(item.infos_values[url_idx])
        else:
            try:
                url = smart_unicode(url) + '&' + smart_unicode(item.infos_names[url_idx]) + ':' + smart_unicode(urllib.quote_plus(item.infos_values[url_idx]))
            except:
                url = smart_unicode(url)
        if len(suffix) > 0:
            url = url + '.' + suffix
        return url

    def decodeUrl(self, url, type = 'rss'):
        item = CListItem()
        if url.find('&') == -1:
            item.infos_names.append('url')
            item.infos_values.append(clean_safe(url))
            item.infos_names.append('type')
            item.infos_values.append(type)
            return item
        infos_names_values = url.split('&')
        for info_name_value in infos_names_values:
            sep_index = info_name_value.find(':')
            if sep_index != -1:
                item.infos_names.append(info_name_value[:sep_index])
                #item.infos_values.append(clean_safe(urllib.unquote(info_name_value[sep_index+1:])))
                item.infos_values.append(clean_safe(info_name_value[sep_index+1:]))
        try:
            type_idx = item.infos_names.index('type')
        except:
            item.infos_names.append('type')
            item.infos_values.append(type)
        return item


    def loadLocal(self, filename, recursive = True, lItem = None):
        params = []
        if filename.find('@') != -1:
            params = filename.split('@')
            filename = params[0]

        # use modules path instead of resources path
        cacheFilename = xbmc.translatePath(os.path.join(cacheDir, filename))
        filename = xbmc.translatePath(os.path.join(modulesDir, filename))

        try:
            data = getFileContent(filename)
            data = customCfgReplacements(data,params)
            data = data.replace('\r\n', '\n')
            data = data.split('\n')
            log('Local file ' + str(os.path.join(modulesDir, filename)) + ' opened')
        except:
            log('File: ' + str(os.path.join(modulesDir, filename)) + ' not found')
            try:
                data = getFileContent(cacheFilename)
                data = customCfgReplacements(data,params)
                data = data.replace('\r\n', '\n')
                data = data.split('\n')
                log('Local file ' + str(cacheFilename) + ' opened')
            except:
                log('File: ' + str(cacheFilename) + ' not found')
                try:
                    data = getFileContent(filename)
                    data = customCfgReplacements(data,params)
                    data = data.replace('\r\n', '\n')
                    data = data.split('\n')
                    log('Local file ' + str(filename) + ' opened')
                except:
                    log('File: ' + str(filename) + ' not found')
                    traceback.print_exc(file = sys.stdout)
                    return -1

        self.cfg = filename
        if self.getFileExtension(self.cfg) == 'cfg' and lItem != None:
            try:
                lItem.infos_values[lItem.infos_names.index(strin)] = self.cfg
            except:
                lItem.infos_names.append('cfg')
                lItem.infos_values.append(self.cfg)
        del self.items[:]
        tmp = None
        for m in data:
            if m and m[0] != '#':
                index = m.find('=')
                if index != -1:
                    key = lower(m[:index])
                    value = m[index+1:]
                    index = value.find('|')
                    if value[:index] == 'sports.devil.locale':
                        #value = ' ' + __language__(int(value[index+1:])) + ' '
                        value = __language__(int(value[index+1:]))
                    elif value[:index] == 'sports.devil.image':
                        value = os.path.join(imgDir, value[index+1:])
                    if key == 'start':
                        self.start = value
                    elif key == 'section':
                        self.section = value
                    elif key == 'player':
                        self.player = value
                    elif key == 'sort':
                        self.sort = value
                    elif key == 'skill':
                        self.skill = value
                        skill_file = filename[:filename.find('.')] + '.lnk'
                        if self.skill.find('redirect') != -1:
                            try:
                                f = open(str(os.path.join(resDir, skill_file)), 'r')
                                forward_cfg = f.read()
                                f.close()
                                if forward_cfg != self.cfg:
                                    return self.loadLocal(forward_cfg, recursive, lItem)
                                return 0
                            except:
                                pass
                        elif self.skill.find('store') != -1:
                            f = open(str(os.path.join(resDir, skill_file)), 'w')
                            f.write(self.cfg)
                            f.close()
                    elif key == 'header':
                        index = value.find('|')
                        self.reference = value[:index]
                        self.content = value[index+1:]
                    elif key == 'item_infos':
                        rule_tmp = CRuleItem()
                        rule_tmp.infos = value
                    elif key == 'item_order':
                        rule_tmp.order = value
                    elif key == 'item_skill':
                        rule_tmp.skill = value
                    elif key == 'item_curr':
                        rule_tmp.curr = value
                    elif key == 'item_info_name':
                        info_tmp = CItemInfo()
                        index = value.find('|')
                        if value[:index] == 'sports.devil.context':
                            value = 'context.' + __language__(int(value[index+1:]))
                        info_tmp.name = value
                    elif key == 'item_info_from':
                        info_tmp.src = value
                    elif key == 'item_info':
                        info_tmp.rule = value
                    elif key == 'item_info_default':
                        info_tmp.default = value
                    elif key == 'item_info_convert':
                        info_tmp.convert.append(value)
                    elif key == 'item_info_build':
                        info_tmp.build = value
                        rule_tmp.info_list.append(info_tmp)
                    elif key == 'item_url_build':
                        rule_tmp.url_build = value
                        self.rules.append(rule_tmp)
                    elif key == 'title':
                        tmp = CListItem()
                        tmp.infos_names.append('title')
                        tmp.infos_values.append(value)
                    elif key == 'type':
                        tmp.infos_names.append('type')
                        if recursive and value == 'once':
                            value = u'rss'
                        tmp.infos_values.append(value)
                    elif key == 'url':
                        tmp.infos_names.append('url')
                        tmp.infos_values.append(value)
                        if lItem != None:
                            for info_name in lItem.infos_names:
                                try:
                                    info_idx = tmp.infos_names.index(info_name)
                                except:
                                    tmp.infos_names.append(info_name)
                                    tmp.infos_values.append(lItem.infos_values[lItem.infos_names.index(info_name)])
                        self.items.append(tmp)
                        tmp = None
                    elif tmp != None:
                        tmp.infos_names.append(key)
                        tmp.infos_values.append(value)

        if recursive and self.start != '':
            if lItem == None:
                self.loadRemote(self.start, False)
            else:
                if self.getFileExtension(lItem.infos_values[lItem.infos_names.index('url')]) == 'cfg':
                    lItem.infos_values[lItem.infos_names.index('url')] = self.start
                    self.loadRemote(self.start, False, lItem)
                else:
                    self.loadRemote(lItem.infos_values[lItem.infos_names.index('url')], False, lItem)

        return 0


    def infoFormatter(self, info_name, info_value, cfg_file): # Site specific info handling
        info_value = info_value.replace('|', '-')
        if cfg_file == 'zdf.de.cfg':
		return clean_safe(info_value.replace('&nbsp;', ' ')).replace("\\'", "\'").replace('\\"', '\"')
        if info_name == 'title':
            try:
                info_value = clean_safe(info_value.replace('\r\n', '').replace('\n', '').replace('\t', ''))
            except:
                info_value = '...'
            if len(info_value) == 0:
                info_value = '...'
            elif cfg_file.find('youtube') != -1: # youtube
                info_value = info_value.replace('<b>', '').replace('</b>', '')
            elif cfg_file.find('boysfood') != -1: # boysfood
                info_value = info_value.replace('<font style="color:#c00000;font-weight:bold;">', '').replace('</font>', '')
        elif info_name == 'icon':
            info_value = decode(unquote_safe(info_value))
            if info_value == '':
                info_value = os.path.join(imgDir, 'video.png')
        return clean_safe(info_value)

    def firstNonEmpty(self, tmp, vars):
        for v in vars:
            vClean = v.strip()
            if vClean.find("'") != -1:
                vClean = vClean.strip("'")
            else:
                vClean = tmp.infos_values[tmp.infos_names.index(vClean)]
            if vClean != '':
                return vClean

        return ''


    def loadRemote(self, remote_url, recursive = True, lItem = None):
        remote_url = urllib.unquote_plus(remote_url)

        setCurrentUrl(remote_url)

        if lItem == None:
            lItem = self.decodeUrl(remote_url)
        try:
            curr_url = remote_url
            if recursive:
                try:
                    if self.loadLocal(lItem.infos_values[lItem.infos_names.index('cfg')], False, lItem) != 0:
                        return -1
                except:
                    pass
                try:
                    if lItem.infos_values[lItem.infos_names.index('type')] == u'search':
                        try:
                            f = open(os.path.join(cacheDir, 'search'), 'r')
                            curr_phrase = urllib.unquote_plus(f.read())
                            f.close()
                        except:
                            curr_phrase = ''
                        search_phrase = self.getKeyboard(default = curr_phrase, heading = __language__(30102))
                        if search_phrase == '':
                            return -1
                        xbmc.sleep(10)
                        f = open(os.path.join(cacheDir, 'search'), 'w')
                        f.write(search_phrase)
                        f.close()
                        curr_url = curr_url % (search_phrase)
                        lItem.infos_values[lItem.infos_names.index('url')] = curr_url
                        lItem.infos_values[lItem.infos_names.index('type')] = u'rss'
                except:
                    pass

            data = getHTML(curr_url,self.reference)

            if self.section != '':
                p = re.compile('.*(' + self.section + ').*', re.IGNORECASE + re.DOTALL + re.MULTILINE)
                m = p.match(data)
                if m:
                    data = m.group(1)
                else:
                    log('section could not be found:' + self.section)

            if enable_debug:
                log('Remote URL ' + str(curr_url) + ' opened')

        except IOError:
            if enable_debug:
                traceback.print_exc(file = sys.stdout)
            return -1

        self.parseItems(data,lItem)

        return 0

    def parseItems(self,data,lItem):
        # Find list items
        reinfos = []
        lock = False
        for item_rule in self.rules:
            if item_rule.skill.find('lock') != -1 and lock:
                continue
            one_found = False
            catfilename = self.randomFilename(prefix=(self.cfg + '.dir.'), suffix = '.list')
            f = None
            if item_rule.order.find('|') != -1:
                reinfos = []
                infos_nbr = len(item_rule.order.split('|'))
                for idx in range(infos_nbr):
                    reinfos.append('')
            else:
                reinfos = ''
            revid = re.compile(item_rule.infos, re.IGNORECASE + re.DOTALL + re.MULTILINE)
            for reinfos in revid.findall(data):
                if item_rule.skill.find('lock') != -1 and lock:
                    continue
                tmp = CListItem()
                if item_rule.order.find('|') != -1:
                    tmp.infos_names = item_rule.order.split('|')
                    tmp.infos_values = list(reinfos)
                else:
                    tmp.infos_names.append(item_rule.order)
                    tmp.infos_values.append(reinfos)
                for info in item_rule.info_list:
                    info_value = ''
                    try:
                        info_idx = tmp.infos_names.index(info.name)
                        if info.build.find('%s') != -1:
                            tmp.infos_values[info_idx] = smart_unicode(info.build % smart_unicode(tmp.infos_values[info_idx]))
                        continue
                    except:
                        pass
                    if info.rule != '':
                        info_rule = info.rule
                        if info.rule.find('%s') != -1:
                            if info.src.find('+') != -1:
                              tmpArr = info.src.split('+')
                              src = ''
                              for t in tmpArr:
                                t = t.strip()
                                if t.find('\'') != -1:
                                  src = src + t.strip('\'')
                                else:
                                  src = src + tmp.infos_values[tmp.infos_names.index(t)]
                            elif info.src.find('||') != -1:
                                vars = info.src.split('||')
                                src = self.firstNonEmpty(tmp, vars)
                            else:
                              src = tmp.infos_values[tmp.infos_names.index(info.src)]
                            if info.convert != []:
                                src = customConversion(src, info.convert)
                                if isinstance(src, dict):
                                    for dKey in src:
                                        tmp.infos_names.append(dKey)
                                        tmp.infos_values.append(src[dKey])
                                    src = src.values()[0]

                            info_rule = info.rule % (smart_unicode(src))
                        infosearch = re.search(info_rule, data)
                        if infosearch:
                            info_value = infosearch.group(1).lstrip().rstrip()
                            if info.build.find('%s') != -1:
                                info_value = info.build % (smart_unicode(info_value))
                        elif info.default != '':
                            info_value = info.default
                    else:
                        if info.build.find('%s') != -1:
                            if info.src.find('+') != -1:
                              tmpArr = info.src.split('+')
                              src = ''
                              for t in tmpArr:
                                t = t.strip()
                                if t.find('\'') != -1:
                                  src = src + t.strip('\'')
                                else:
                                  src = src + smart_unicode(tmp.infos_values[tmp.infos_names.index(t)])
                            elif info.src.find('||') != -1:
                                vars = info.src.split('||')
                                src = self.firstNonEmpty(tmp, vars)
                            else:
                              src = tmp.infos_values[tmp.infos_names.index(info.src)]
                            if info.convert != []:
                                src = customConversion(src, info.convert)
                                if isinstance(src, dict):
                                    for dKey in src:
                                        tmp.infos_names.append(dKey)
                                        tmp.infos_values.append(src[dKey])
                                    src = src.values()[0]

                            info_value = info.build % (smart_unicode(src))
                        else:
                            info_value = info.build
                    tmp.infos_names.append(info.name)
                    tmp.infos_values.append(info_value)
                info_idx = 0
                for info_name in tmp.infos_names:
                    tmp.infos_values[info_idx] = self.infoFormatter(info_name, tmp.infos_values[info_idx], self.cfg)
                    if info_name.rfind('.append') != -1:
                        tmp.infos_values[tmp.infos_names.index(info_name[:info_name.rfind('.append')])] = smart_unicode(tmp.infos_values[tmp.infos_names.index(info_name[:info_name.rfind('.append')])]) + smart_unicode(tmp.infos_values[info_idx])
                    info_idx = info_idx + 1
                info_idx = tmp.infos_names.index('url')
                tmp.infos_values[info_idx] = smart_unicode(item_rule.url_build % (smart_unicode(tmp.infos_values[info_idx])))
                if item_rule.skill.find('append') != -1:
                    tmp.infos_values[info_idx] = curr_url + tmp.infos_values[info_idx]
                if item_rule.skill.find('space') != -1:
                    try:
                        tmp.infos_values[tmp.infos_names.index('title')] = ' ' + tmp.infos_values[tmp.infos_names.index('title')].lstrip().rstrip() + ' '
                    except:
                        pass
                for info_name in lItem.infos_names:
                    try:
                        info_idx = tmp.infos_names.index(info_name)
                    except:
                        tmp.infos_names.append(info_name)
                        tmp.infos_values.append(lItem.infos_values[lItem.infos_names.index(info_name)])
                if item_rule.skill.find('recursive') != -1:
                    self.loadRemote(tmp.infos_values[tmp.infos_names.index('url')], False, tmp)
                    tmp = None
                else:
                    if item_rule.skill.find('directory') != -1:
                        one_found = True
                        if f == None:
                            f = open(str(os.path.join(cacheDir, catfilename)), 'w')
                            f.write(smart_unicode('########################################################\n').encode('utf-8'))
                            f.write(smart_unicode('#                    Temporary file                    #\n').encode('utf-8'))
                            f.write(smart_unicode('########################################################\n').encode('utf-8'))
                        try:
                            f.write(smart_unicode('title=' + tmp.infos_values[tmp.infos_names.index('title')] + '\n').encode('utf-8'))
                        except:
                            f.write(smart_unicode('title=...\n').encode('utf-8'))
                        for info_name in tmp.infos_names:
                            if info_name != 'url' and info_name != 'title':
                                f.write(smart_unicode(info_name + '=' + tmp.infos_values[tmp.infos_names.index(info_name)] + '\n').encode('utf-8'))
                        f.write(smart_unicode('url=' + tmp.infos_values[tmp.infos_names.index('url')] + '\n').encode('utf-8'))
                        f.write(smart_unicode('########################################################\n').encode('utf-8'))
                    else:
                        self.items.append(tmp)
                    if item_rule.skill.find('lock') != -1:
                        lock = True
            if item_rule.curr != '':
                revid = re.compile(item_rule.curr, re.IGNORECASE + re.DOTALL + re.MULTILINE)
                for title in revid.findall(data):
                    tmp = CListItem()
                    tmp.infos_names.append('title')
                    if item_rule.skill.find('space') != -1:
                        tmp.infos_values.append('  ' + clean_safe(title.lstrip().rstrip()) + ' (' + __language__(30106) +')  ')
                    else:
                        tmp.infos_values.append(' ' + clean_safe(title.lstrip().rstrip()) + ' (' + __language__(30106) +') ')
                    tmp.infos_names.append('url')
                    tmp.infos_values.append(curr_url)
                    for info in item_rule.info_list:
                        if info.name == 'icon':
                            tmp.infos_names.append('icon')
                            if info.default != '':
                                tmp.infos_values.append(info.default)
                            else:
                                tmp.infos_values.append(info.build)
                    for info_name in lItem.infos_names:
                        try:
                            info_idx = tmp.infos_names.index(info_name)
                        except:
                            tmp.infos_names.append(info_name)
                            tmp.infos_values.append(lItem.infos_values[lItem.infos_names.index(info_name)])
                    if item_rule.skill.find('directory') != -1:
                        one_found = True
                        if f == None:
                            f = open(str(os.path.join(cacheDir, catfilename)), 'w')
                            f.write(smart_unicode('########################################################\n').encode('utf-8'))
                            f.write(smart_unicode('#                    Temporary file                    #\n').encode('utf-8'))
                            f.write(smart_unicode('########################################################\n').encode('utf-8'))
                        f.write(smart_unicode('title=' + tmp.infos_values[tmp.infos_names.index('title')] + '\n').encode('utf-8'))
                        for info_name in tmp.infos_names:
                            if info_name != 'url' and info_name != 'title':
                                f.write(smart_unicode(info_name + '=' + tmp.infos_values[tmp.infos_names.index(info_name)] + '\n').encode('utf-8'))
                        f.write(smart_unicode('url=' + tmp.infos_values[tmp.infos_names.index('url')] + '\n').encode('utf-8'))
                        f.write(smart_unicode('########################################################\n').encode('utf-8'))
                    else:
                        self.items.append(tmp)
                    if item_rule.skill.find('lock') != -1:
                        lock = True
            if one_found:
                tmp = CListItem()
                tmp.infos_names.append('url')
                tmp.infos_values.append(catfilename)
                for info in item_rule.info_list:
                    if info.name == 'title':
                        tmp.infos_names.append('title')
                        tmp.infos_values.append(' ' + info.build + ' ')
                    elif info.name == 'icon':
                        tmp.infos_names.append('icon')
                        if info.default != '':
                            tmp.infos_values.append(info.default)
                        else:
                            tmp.infos_values.append(info.build)
                for info_name in lItem.infos_names:
                    try:
                        info_idx = tmp.infos_names.index(info_name)
                    except:
                        tmp.infos_names.append(info_name)
                        tmp.infos_values.append(lItem.infos_values[lItem.infos_names.index(info_name)])
                self.items.append(tmp)
                if item_rule.skill.find('lock') != -1:
                    lock = True
            if f != None:
                f.write(smart_unicode('########################################################\n').encode('utf-8'))
                f.close()