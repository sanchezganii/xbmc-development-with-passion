# -*- coding: latin-1 -*-

from string import *
import xbmcplugin, xbmcaddon
import sys, os.path
import urllib,urllib2, filecmp
import re, random, string, shutil
import xbmc, xbmcgui
import re, os, time, datetime, traceback
import cookielib, htmlentitydefs
import socket, base64

def smart_unicode(s):
    if not s:
        return ''
    try:
        if not isinstance(s, basestring):
            if hasattr(s, '__unicode__'):
                s = unicode(s)
            else:
                s = unicode(str(s), 'UTF-8')
        elif not isinstance(s, unicode):
            s = unicode(s, 'UTF-8')
    except:
        if not isinstance(s, basestring):
            if hasattr(s, '__unicode__'):
                s = unicode(s)
            else:
                s = unicode(str(s), 'ISO-8859-1')
        elif not isinstance(s, unicode):
            s = unicode(s, 'ISO-8859-1')
    return s

def safeGerman(src):
    try:
        src = src.encode('latin-1')
    except:
        xbmc.output('Unicode Error')
    
    tmp = '[^<]*'
            
    try:
        src = src.replace('ä',tmp)
    except:
        try:
            src = src.replace(u'ä',tmp)
        except:
            if enable_debug:
                xbmc.output('Unicode Error')
    
    try:
        src = src.replace('&#223;',tmp)
    except:
        try:
            src = src.replace(u'&#223;',tmp)
        except:
            if enable_debug:
                xbmc.output('Unicode Error')                
                
    return src
    
    
def timediff(mytime, unit='seconds'):
    dtNow = datetime.datetime.utcnow()
    datePart = mytime.split(' ')[0]
    dpArr = datePart.split('/')
    timePart = mytime.split(' ')[1]
    tpArr = timePart.split(':')
    d = datetime.date(int(dpArr[0]), int(dpArr[1]), int(dpArr[2]))
    t = datetime.time(int(tpArr[0]), int(tpArr[1]))
    dt = datetime.datetime.combine(d,t)
    
    diff = dtNow - dt

    if unit == 'seconds':
        return str(diff.seconds)
    elif unit == 'minutes':
        return str(diff.seconds/60)    
    elif unit == 'sapo':
        #Math.floor(new Date().getTime()/1000)-Math.floor(new Date().getTime()/1000)-time
        #return str(1304805500 + diff.seconds*75)
        return time.time()
    else:
        return '0'

def getFileContent(filename):
    try:
        f = open(filename,'r')
        txt = smart_unicode(f.read())
        f.close()
        return txt
    except:
        return ''
