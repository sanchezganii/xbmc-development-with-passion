# -*- coding: latin-1 -*-

from string import *
import xbmcplugin, xbmcaddon
import sys, os.path
import urllib,urllib2, filecmp
import re, random, string, shutil
import xbmc, xbmcgui
import re, os, time, datetime, traceback
import cookielib, htmlentitydefs
from sportsdevil import *

enable_debug = True
__settings__ = xbmcaddon.Addon(id='plugin.video.SportsDevil')
__language__ = __settings__.getLocalizedString

class Main:
    
    def __init__(self):
        self.log('Initializing SportsDevil')
        self.pDialog = None
        self.curr_file = ''
        self.urlList = []
        self.extensionList = []
        self.selectionList = []
        self.videoExtension = '.flv'
        self.currentlist = CCurrentList()
        self.log('SportsDevil initialized')
        self.run()

    def getDirectLink(self, orig_url):
        orig_url = orig_url.replace('\r\n', '').replace('\n', '')
        self.videoExtension = '.flv'
        for source in self.currentlist.catcher:
            if len(self.urlList) > 0 and source.quality == 'fallback':
                continue
            if source.rule.url != '':
                if source.rule.data == '':
                    url = source.rule.url % orig_url
                    req = Request(url)
                else:
                    url = source.rule.data % orig_url
                    req = Request(source.rule.url, url)
                    
                req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
                if source.rule.reference != '':
                    req.add_header(source.rule.reference, source.rule.content)
                response = urlopen(req)
                if source.rule.limit == 0:
                    fc = response.read()
                else:
                    fc = response.read(source.rule.limit)
                    
                if enable_debug:
                    f = open(os.path.join(cacheDir, 'catcher.html'), 'w')
                    f.write('<Titel>'+ orig_url + '</Title>\n\n')
                    f.write(fc)
                    f.close()
                                      
            urlsearch = re.search(source.rule.target, fc)
            match = ''
            if urlsearch:
                match = urlsearch.group(1).replace('\r\n', '').replace('\n', '').lstrip().rstrip()
                if source.rule.action.find('unquote') != -1:
                    match = unquote_safe(match)
                if source.rule.build.find('%s') != -1:
                    match = source.rule.build % match
                if source.ext_rule != None:
                    if source.ext_rule.data == '':
                        if source.ext_rule.url.find('%s') != -1:
                            ext_url = source.ext_rule.url % match
                        else:
                            ext_url = match
                        ext_req = Request(ext_url)
                        ext_req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
                        if source.ext_rule.reference != '':
                            ext_req.add_header(source.ext_rule.reference, source.ext_rule.content)
                        ext_response = opener.open(ext_req)
                    else:
                        ext_data = source.ext_rule.data % match
                        ext_req = Request(source.ext_rule.url, ext_data)
                        ext_req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
                        if source.ext_rule.reference != '':
                            ext_req.add_header(source.ext_rule.reference, source.ext_rule.content)
                        ext_response = urlopen(ext_req)
                        
                    if source.ext_rule.limit == 0:
                        ext_fc = ext_response.read()
                    else:
                        ext_fc = ext_response.read(source.ext_rule.limit)
                         
                    if enable_debug:
                        f = open(os.path.join(cacheDir, 'ext_catcher.html'), 'w')
                        f.write('<Titel>'+ match + '</Title>\n\n')
                        f.write(ext_fc)
                        f.close()
                    ext_urlsearch = re.search(source.ext_rule.target, ext_fc)
                    if ext_urlsearch:
                        match = ext_urlsearch.group(1).replace('\r\n', '').replace('\n', '').lstrip().rstrip()
                        if source.ext_rule.action.find('unquote') != -1:
                            match = unquote_safe(match)
                        if source.ext_rule.build.find('%s') != -1:
                            match = source.ext_rule.build % match
                    else:
                        match = ''
                source.match = match
                if source.match != '':
                    self.urlList.append(source.match)
                    self.extensionList.append(source.extension)
                    if source.quality == 'fallback':
                        self.videoExtension = '.' + source.extension
                        return source.match
                    elif source.quality == 'low':
                        if source.info == '':
                            self.selectionList.append(__language__(30056) + ' (' + source.extension + ')')
                        else:
                            self.selectionList.append(__language__(30056) + ' (' + source.info + ')')
                    elif source.quality == 'standard':
                        if source.info == '':
                            self.selectionList.append(__language__(30057) + ' (' + source.extension + ')')
                        else:
                            self.selectionList.append(__language__(30057) + ' (' + source.info + ')')
                    elif source.quality == 'high':
                        if source.info == '':
                            self.selectionList.append(__language__(30058) + ' (' + source.extension + ')')
                        else:
                            self.selectionList.append(__language__(30058) + ' (' + source.info + ')')

        if len(self.urlList) > 0:
            if len(self.urlList) == 1:
                self.videoExtension = '.' + self.extensionList[0]
                return self.urlList[0]
            elif int(__settings__.getSetting('video_type')) == 0:
                dia = xbmcgui.Dialog()
                selection = dia.select(__language__(30055), self.selectionList)
                self.videoExtension = '.' + self.extensionList[selection]
                return self.urlList[selection]
            elif int(__settings__.getSetting('video_type')) == 1: # low
                for source in self.currentlist.catcher:
                    if source.quality == 'low' and source.match != '':
                        self.videoExtension = '.' + source.extension
                        return source.match
                for source in self.currentlist.catcher:
                    if source.quality == 'standard' and source.match != '':
                        self.videoExtension = '.' + source.extension
                        return source.match
                for source in self.currentlist.catcher:
                    if source.quality == 'high' and source.match != '':
                        self.videoExtension = '.' + source.extension
                        return source.match
            elif int(__settings__.getSetting('video_type')) == 3: # high
                for source in self.currentlist.catcher:
                    if source.quality == 'high' and source.match != '':
                        self.videoExtension = '.' + source.extension
                        return source.match
                for source in self.currentlist.catcher:
                    if source.quality == 'standard' and source.match != '':
                        self.videoExtension = '.' + source.extension
                        return source.match
                for source in self.currentlist.catcher:
                    if source.quality == 'low' and source.match != '':
                        self.videoExtension = '.' + source.extension
                        return source.match
            elif int(__settings__.getSetting('video_type')) == 2: # standard
                for source in self.currentlist.catcher:
                    if source.quality == 'standard' and source.match != '':
                        self.videoExtension = '.' + source.extension
                        return source.match
                for source in self.currentlist.catcher:
                    if source.quality == 'low' and source.match != '':
                        self.videoExtension = '.' + source.extension
                        return source.match
                for source in self.currentlist.catcher:
                    if source.quality == 'high' and source.match != '':
                        self.videoExtension = '.' + source.extension
                        return source.match
        return ''

    def playVideo(self, videoItem):       
        if videoItem == None:
            return
        if videoItem.infos_values[videoItem.infos_names.index('url')] == '':
            return
        url = videoItem.infos_values[videoItem.infos_names.index('url')]
        try:
            title = videoItem.infos_values[videoItem.infos_names.index('title')]
        except:
            title = '...'
        
        if url.startswith('call://'):
            call_url = url.replace('call://','')
            xbmc.executebuiltin('XBMC.RunPlugin(' + call_url +')')
            if call_url.startswith('plugin://plugin.program.jdownloader'):
              xbmc.executebuiltin('Notification(Sent to JDownloader:,' + str(title) + ')')
            return;
        try:
            icon = videoItem.infos_values[videoItem.infos_names.index('icon')]
        except:
            icon = os.path.join(imgDir, 'video.png')
        try:
            urllib.urlretrieve(icon, os.path.join(cacheDir, 'thumb.tbn'))
            icon = os.path.join(cacheDir, 'thumb.tbn')
        except:
            if enable_debug:
                traceback.print_exc(file = sys.stdout)
            icon = os.path.join(imgDir, 'video.png')
        url = urllib.unquote_plus(url)
        flv_file = url
        listitem = xbmcgui.ListItem(title, title, icon, icon)
        listitem.setInfo('video', {'Title':title})
        #listitem.setProperty('IsFolder','false')
        #listitem.setProperty('IsPlayable','true')
        #xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listitem)

        for video_info_name in videoItem.infos_names:
            try:
                listitem.setInfo(type = 'Video', infoLabels = {video_info_name: videoItem.infos_values[videoItem.infos_names.index(video_info_name)]})
            except:
                pass
        if self.currentlist.skill.find('nodownload') == -1:
            if __settings__.getSetting('download') == 'true':
                self.pDialog = xbmcgui.DialogProgress()
                self.pDialog.create('SportsDevil', __language__(30050), __language__(30051))
                flv_file = self.downloadMovie(url, title)
                self.pDialog.close()
                if flv_file == None:
                    dialog = xbmcgui.Dialog()
                    dialog.ok('SportsDevil Info', __language__(30053))
            elif __settings__.getSetting('download') == 'false' and __settings__.getSetting('download_ask') == 'true':
                dia = xbmcgui.Dialog()
                if dia.yesno('', __language__(30052)):
                    self.pDialog = xbmcgui.DialogProgress()
                    self.pDialog.create('SportsDevil', __language__(30050), __language__(30051))
                    flv_file = self.downloadMovie(url, title)
                    self.pDialog.close()
                    if flv_file == None:
                        dialog = xbmcgui.Dialog()
                        dialog.ok('SportsDevil Info', __language__(30053))
        else:
            flv_file = None

        player_type = {0:xbmc.PLAYER_CORE_AUTO, 1:xbmc.PLAYER_CORE_MPLAYER, 2:xbmc.PLAYER_CORE_DVDPLAYER}[int(__settings__.getSetting('player_type'))]
        if self.currentlist.player == 'auto':
            player_type = xbmc.PLAYER_CORE_AUTO
        elif self.currentlist.player == 'mplayer':
            player_type = xbmc.PLAYER_CORE_MPLAYER
        elif self.currentlist.player == 'dvdplayer':
            player_type = xbmc.PLAYER_CORE_DVDPLAYER
        if flv_file != None and os.path.isfile(flv_file):
            self.log('Play: ' + str(flv_file))
            xbmc.Player(player_type).play(str(flv_file), listitem)
        else:
            self.log('Play: ' + str(url))
            xbmc.Player(player_type).play(str(url), listitem)
        xbmc.sleep(200)

    def downloadMovie(self, url, title):
        self.log('Trying to download video ' + str(url))
	if __settings__.getSetting('download_Path') == '':
	    try:
		dl_path = xbmcgui.Dialog().browse(0, __language__(30017),'files', '', False, False)
		__settings__.setSetting(id='download_path', value=dl_path)
		if not os.path.exists(dl_path):
		    os.mkdir(dl_path)
	    except:pass
        file_path = xbmc.makeLegalFilename(os.path.join(__settings__.getSetting('download_Path'), title + self.videoExtension))
        if os.path.isfile(file_path):
            file_path = xbmc.makeLegalFilename(self.currentlist.randomFilename(prefix = file_path[:file_path.rfind('.')] + '&', suffix = self.videoExtension))
        try:
            urllib.urlretrieve(url, file_path, self.video_report_hook)
            self.log('Video ' + str(url) + ' downloaded to ' + repr(file_path))
            return file_path
        except IOError:
            title = first_clean_filename(title)
            file_path = xbmc.makeLegalFilename(os.path.join(__settings__.getSetting('download_Path'), title + self.videoExtension))
            if os.path.isfile(file_path):
                file_path = xbmc.makeLegalFilename(self.currentlist.randomFilename(prefix = file_path[:file_path.rfind('.')] + '&', suffix = self.videoExtension))
            try:
                urllib.urlretrieve(url, file_path, self.video_report_hook)
                self.log('Video ' + str(url) + ' downloaded to ' + repr(file_path))
                return file_path
            except IOError:
                title = second_clean_filename(title)
                file_path = xbmc.makeLegalFilename(os.path.join(__settings__.getSetting('download_Path'), title + self.videoExtension))
                if os.path.isfile(file_path):
                    file_path = xbmc.makeLegalFilename(self.currentlist.randomFilename(prefix = file_path[:file_path.rfind('.')] + '&', suffix = self.videoExtension))
                try:
                    urllib.urlretrieve(url, file_path, self.video_report_hook)
                    self.log('Video ' + str(url) + ' downloaded to ' + repr(file_path))
                    return file_path
                except IOError:
                    title = third_clean_filename(title)
                    file_path = xbmc.makeLegalFilename(os.path.join(__settings__.getSetting('download_Path'), title + self.videoExtension))
                    if os.path.isfile(file_path):
                        file_path = xbmc.makeLegalFilename(self.currentlist.randomFilename(dir = __settings__.getSetting('download_Path'), suffix = self.videoExtension))
                    try:
                        urllib.urlretrieve(url, file_path, self.video_report_hook)
                        self.log('Video ' + str(url) + ' downloaded to ' + repr(file_path))
                        return file_path
                    except IOError:
                        title = self.currentlist.randomFilename()
                        file_path = xbmc.makeLegalFilename(os.path.join(__settings__.getSetting('download_Path'), title + self.videoExtension))
                        if os.path.isfile(file_path):
                            file_path = xbmc.makeLegalFilename(self.currentlist.randomFilename(prefix = file_path[:file_path.rfind('.')] + '&', suffix = self.videoExtension))
                        try:
                            urllib.urlretrieve(url, file_path, self.video_report_hook)
                            self.log('Video ' + str(url) + ' downloaded to ' + repr(file_path))
                            return file_path
                        except:
                            pass
                    except:
                        pass
                except:
                    pass
            except:
                pass
        except:
            pass
        xbmc.sleep(500)
        if os.path.isfile(file_path):
            try:
                os.remove(file_path)
            except:
                if enable_debug:
                    traceback.print_exc(file = sys.stdout)
        return None

    def video_report_hook(self, count, blocksize, totalsize):
        percent = int(float(count * blocksize * 100) / totalsize)
        self.pDialog.update(percent, __language__(30050), __language__(30051))
        if self.pDialog.iscanceled():
            raise KeyboardInterrupt

    def TargetFormatter(self, url, cfg_file): # Site specific target url handling
        return url

    def parseView(self, url): 
        lItem = self.currentlist.decodeUrl(url)
        url = lItem.infos_values[lItem.infos_names.index('url')]
        ext = self.currentlist.getFileExtension(url)
        if ext == 'cfg' or ext == 'list':
            result = self.currentlist.loadLocal(url, lItem = lItem)
        elif ext == 'add':
	    url = urllib.unquote_plus(url)
            self.currentlist.addItem(url[:len(url) - 4])
            return -2
        elif ext == 'remove':
            dia = xbmcgui.Dialog()
            if dia.yesno('', __language__(30054)):
		url = urllib.unquote_plus(url)
                self.currentlist.removeItem(url[:len(url) - 7])
                xbmc.executebuiltin('Container.Refresh')
            return -2
        elif ext == 'videodevil' or ext == 'dwnlddevil':
	    url = urllib.unquote_plus(url)		
            url = url[:len(url) - 11]
            lItem.infos_values[lItem.infos_names.index('url')] = url
            cfg_file = lItem.infos_values[lItem.infos_names.index('cfg')]
            if lItem.infos_values[lItem.infos_names.index('type')] == 'video':
                self.currentlist.loadLocal(cfg_file, False, lItem, True)
                lItem.infos_values[lItem.infos_names.index('url')] = self.getDirectLink(lItem.infos_values[lItem.infos_names.index('url')])
            lItem.infos_values[lItem.infos_names.index('url')] = self.TargetFormatter(lItem.infos_values[lItem.infos_names.index('url')], cfg_file)
            try:
                self.videoExtension = '.' + lItem.infos_values[lItem.infos_names.index('extension')]
            except:
                pass
            if ext == 'videodevil':
                result = self.playVideo(lItem)
            else:
                self.pDialog = xbmcgui.DialogProgress()
                self.pDialog.create('SportsDevil', __language__(30050), __language__(30051))
                self.downloadMovie(lItem.infos_values[lItem.infos_names.index('url')], lItem.infos_values[lItem.infos_names.index('title')])
                self.pDialog.close()
            return -2
        else:
            result = self.currentlist.loadRemote(lItem.infos_values[lItem.infos_names.index('url')], lItem = lItem)

        xbmcplugin.addSortMethod(handle = self.handle, sortMethod = xbmcplugin.SORT_METHOD_LABEL)
        if self.currentlist.sort.find('label') != -1:
            xbmcplugin.addSortMethod(handle = self.handle, sortMethod = xbmcplugin.SORT_METHOD_LABEL)
        if self.currentlist.sort.find('size') != -1:
            xbmcplugin.addSortMethod(handle = self.handle, sortMethod = xbmcplugin.SORT_METHOD_SIZE)
        if self.currentlist.sort.find('duration') != -1:
            xbmcplugin.addSortMethod(handle = self.handle, sortMethod = xbmcplugin.SORT_METHOD_DURATION)
        if self.currentlist.sort.find('genre') != -1:
            xbmcplugin.addSortMethod(handle = self.handle, sortMethod = xbmcplugin.SORT_METHOD_GENRE)
        if self.currentlist.sort.find('rating') != -1:
            xbmcplugin.addSortMethod(handle = self.handle, sortMethod = xbmcplugin.SORT_METHOD_VIDEO_RATING)
        if self.currentlist.sort.find('date') != -1:
            xbmcplugin.addSortMethod(handle = self.handle, sortMethod = xbmcplugin.SORT_METHOD_DATE)

        if self.currentlist.skill.find('play') != -1 and len(self.currentlist.items) == 1 and self.currentlist.videoCount() == 1:            
            videoItem = self.currentlist.getVideo()            
            url = self.currentlist.codeUrl(videoItem, 'videodevil')
            result = self.parseView(url)
        elif self.currentlist.skill.find('play') != -1 and len(self.currentlist.items) == 0 and self.currentlist.videoCount() == 0:
            dialog = xbmcgui.Dialog()
            dialog.ok('SportsDevil Info', 'no stream available')
            return
        else:
            for m in self.currentlist.items:
                m_url = m.infos_values[m.infos_names.index('url')]
                try:
                    m_type = m.infos_values[m.infos_names.index('type')]
                except:
                    m_type = 'rss'   
                m_icon = m.infos_values[m.infos_names.index('icon')]
                m_title = clean_safe(m.infos_values[m.infos_names.index('title')])
                
                if m_type == 'search' and 'once' in m.infos_names:
                    p_reg = re.compile('^' + m.infos_values[m.infos_names.index('once')] + '$', re.IGNORECASE + re.DOTALL + re.MULTILINE)
                    m_reg = p_reg.match(unquote_safe(url))
                    if  (m_reg is None):
                        continue                 
                            
                if m_type == 'rss' or m_type == 'search': 
                    self.addListItem(m_title, self.currentlist.codeUrl(m), m_icon, len(self.currentlist.items), m)    
                elif m_type.find('video') != -1:
                    self.addListItem(m_title, self.currentlist.codeUrl(m, 'videodevil'), m_icon, len(self.currentlist.items), m)
        return result

    def addListItem(self, title, url, icon, totalItems, lItem):
        u = sys.argv[0] + '?url=' + url
        liz = xbmcgui.ListItem(title, title, icon, icon)
        liz.setProperty('fanart_image', os.path.join(rootDir, 'fanart.jpg'))
        if self.currentlist.getFileExtension(url) == 'videodevil' and self.currentlist.skill.find('nodownload') == -1:
            action = 'XBMC.RunPlugin(%s.dwnlddevil)' % u[:len(u)-11]
            try:
                liz.addContextMenuItems([(__language__(30007), action)])
            except:
                pass
        if self.currentlist.skill.find('add') != -1:
            action = 'XBMC.RunPlugin(%s.add)' % u
            try:
                liz.addContextMenuItems([(__language__(30010), action)])
            except:
                pass
        if self.currentlist.skill.find('remove') != -1:
            action = 'XBMC.RunPlugin(%s.remove)' % u
            try:
                liz.addContextMenuItems([(__language__(30011), action)])
            except:
                pass
        for video_info_name in lItem.infos_names:
            if video_info_name.find('context.') != -1:
                try:
                    cItem = lItem
                    cItem.infos_values[lItem.infos_names.index('url')] = lItem.infos_values[lItem.infos_names.index(video_info_name)]
                    cItem.infos_values[lItem.infos_names.index('type')] = 'rss'
                    action = 'XBMC.RunPlugin(%s)' % (sys.argv[0] + '?url=' + self.currentlist.codeUrl(cItem))
                    liz.addContextMenuItems([(video_info_name[video_info_name.find('.') + 1:], action)])
                except:
                    pass
            if video_info_name.find('.append') == -1 and video_info_name != 'url' and video_info_name != 'title' and video_info_name != 'icon' and video_info_name != 'type' and video_info_name != 'extension' and video_info_name.find('.tmp') == -1 and video_info_name.find('.append') == -1 and video_info_name.find('context.') == -1:
                try:
                    if video_info_name.find('.int') != -1:
                        liz.setInfo(type = 'Video', infoLabels = {capitalize(video_info_name[:video_info_name.find('.int')]): int(lItem.infos_values[lItem.infos_names.index(video_info_name)])})
                    elif video_info_name.find('.once') != -1:
                        liz.setInfo(type = 'Video', infoLabels = {capitalize(video_info_name[:video_info_name.find('.once')]): lItem.infos_values[lItem.infos_names.index(video_info_name)]})
                    else:
                        liz.setInfo(type = 'Video', infoLabels = {capitalize(video_info_name): lItem.infos_values[lItem.infos_names.index(video_info_name)]})
                except:
                    pass  
        xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True, totalItems = totalItems)

    def purgeCache(self):
        for root, dirs, files in os.walk(cacheDir , topdown = False):
            for name in files:
                os.remove(os.path.join(root, name))

    def log(self, msg, err=False):
        if err:
            xbmc.log('SportsDevil: ' + msg.encode('utf-8'), xbmc.LOGERROR)    
        else:
            if enable_debug:
                xbmc.log('SportsDevil: ' + msg.encode('utf-8'), xbmc.LOGDEBUG)
            
    def run(self):
        self.log('SportsDevil running')
        try:
            self.handle = int(sys.argv[1])
            xbmcplugin.setPluginFanart(self.handle, os.path.join(rootDir, 'fanart.jpg'))
            paramstring = sys.argv[2] 
            if len(paramstring) <= 2:
                if __settings__.getSetting('hide_warning') == 'false':
                    dialog = xbmcgui.Dialog()
                    if not dialog.yesno(__language__(30061), __language__(30062), __language__(30063), __language__(30064), __language__(30065), __language__(30066)):
                        return
                self.log('Cache directory: ' + str(cacheDir))
                self.log('Resource directory: ' + str(resDir))
                self.log('Image directory: ' + str(imgDir))
                
                if not os.path.exists(cacheDir):
                    self.log('Creating cache directory ' + str(cacheDir))
                    os.mkdir(cacheDir)
                    self.log('Cache directory created')
                
                self.log('Purging cache directory')
                self.purgeCache()
                self.log('Cache directory purged')
                
                self.parseView('sites.list')
                del self.currentlist.items[:]
                self.log('End of directory')
                xbmcplugin.endOfDirectory(handle = int(sys.argv[1]))
            else:
                params = sys.argv[2]
                currentView = params[5:]
                self.log(repr(currentView))
                if self.parseView(currentView) == 0:
                    xbmcplugin.endOfDirectory(int(sys.argv[1]))
                    self.log('End of directory')
        except Exception, e:
            if enable_debug:
                traceback.print_exc(file = sys.stdout)
            dialog = xbmcgui.Dialog()
            dialog.ok('SportsDevil Error', 'Error running SportsDevil.\n\nReason:\n' + str(e))
